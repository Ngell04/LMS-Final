-- ====================================================================
-- KBZLIFE LMS: COMPLETE MASTER DATABASE SCHEMA & SECURE RBAC
-- File: 20261028_master_setup_all_in_one.sql
-- Description: Self-contained, idempotent master migration script.
-- Modules:
--   1. Extensions & Custom Types
--   2. Profiles Table & 3-Tier RBAC ('super_admin', 'admin', 'user')
--   3. Concurrency-Safe 20 Active Admin Cap Trigger
--   4. Last Super Admin Protection Triggers (Update & Delete)
--   5. First Super Admin Bootstrap Function (One-time secure initialization)
--   6. Auth Registration Hook Trigger (Enforces Pending status & User role)
--   7. Core LMS Tables (Courses, Channels, Enrollments, Progress, Audit)
--   8. News, Videos, Top Performers, Team & Motto
--   9. License Training (Chapters, Lessons, Quizzes, Attempts)
--   10. Skill Development (Categories, Resources, Quizzes, Attempts)
--   11. Product Knowledge Hub (Items, Quizzes, Attempts)
--   12. Company Bulletins (Announcements, Directives, PDFs)
--   13. Storage Buckets (Public media & Private training/bulletins)
--   14. Complete Row Level Security (RLS) Policies on All Tables & Storage
--   15. Initial Seed Data & Initial Super Admin Provisioning
-- ====================================================================

-- --------------------------------------------------------------------
-- 1. EXTENSIONS
-- --------------------------------------------------------------------
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- --------------------------------------------------------------------
-- 2. PROFILES TABLE (Linked to auth.users)
-- --------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.profiles (
    id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
    username TEXT UNIQUE,
    full_name TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE,
    role TEXT NOT NULL DEFAULT 'user',
    account_status TEXT NOT NULL DEFAULT 'pending',
    employee_id TEXT,
    department TEXT DEFAULT 'KBZLife Insurance Operations',
    avatar_url TEXT,
    must_change_password BOOLEAN DEFAULT false,
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now()),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now()),
    last_sign_in_at TIMESTAMPTZ
);

-- Ensure Constraints
DO $$
BEGIN
    ALTER TABLE public.profiles DROP CONSTRAINT IF EXISTS profiles_role_check;
    ALTER TABLE public.profiles ADD CONSTRAINT profiles_role_check
        CHECK (role IN ('super_admin', 'admin', 'user'));
EXCEPTION WHEN OTHERS THEN NULL;
END $$;

DO $$
BEGIN
    ALTER TABLE public.profiles DROP CONSTRAINT IF EXISTS profiles_account_status_check;
    ALTER TABLE public.profiles ADD CONSTRAINT profiles_account_status_check
        CHECK (account_status IN ('active', 'approved', 'pending', 'rejected', 'suspended', 'inactive'));
EXCEPTION WHEN OTHERS THEN NULL;
END $$;

CREATE INDEX IF NOT EXISTS idx_profiles_role ON public.profiles(role);
CREATE INDEX IF NOT EXISTS idx_profiles_status ON public.profiles(account_status);
CREATE INDEX IF NOT EXISTS idx_profiles_email ON public.profiles(LOWER(email));

-- --------------------------------------------------------------------
-- 3. RBAC SECURITY HELPER FUNCTIONS
-- --------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.is_admin(lookup_user_id UUID)
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.profiles
    WHERE id = lookup_user_id
      AND role IN ('super_admin', 'admin')
      AND account_status IN ('active', 'approved')
  );
$$;

CREATE OR REPLACE FUNCTION public.is_super_admin(lookup_user_id UUID)
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.profiles
    WHERE id = lookup_user_id
      AND role = 'super_admin'
      AND account_status IN ('active', 'approved')
  );
$$;

CREATE OR REPLACE FUNCTION public.is_account_active(lookup_user_id UUID)
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.profiles
    WHERE id = lookup_user_id
      AND account_status IN ('active', 'approved')
  );
$$;

-- --------------------------------------------------------------------
-- 4. CONCURRENCY-SAFE 20 ADMIN LIMIT & LAST SUPER ADMIN DEFENSE
-- --------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.check_admin_account_limit()
RETURNS TRIGGER AS $$
DECLARE
  v_admin_count INTEGER;
  v_super_admin_count INTEGER;
BEGIN
  -- If transitioning to or created as an active administrator
  IF (NEW.role IN ('admin', 'super_admin') AND NEW.account_status IN ('active', 'approved')) THEN
    -- Concurrency defense: lock active admin rows to prevent race condition promotions
    PERFORM 1 FROM public.profiles WHERE role IN ('admin', 'super_admin') FOR UPDATE;
    
    SELECT COUNT(*) INTO v_admin_count
    FROM public.profiles
    WHERE role IN ('admin', 'super_admin')
      AND account_status IN ('active', 'approved')
      AND id <> COALESCE(NEW.id, '00000000-0000-0000-0000-000000000000'::uuid);

    IF v_admin_count >= 20 THEN
      RAISE EXCEPTION 'Maximum limit of 20 active administrator accounts has been reached. Cannot promote or activate additional administrator accounts.';
    END IF;
  END IF;

  -- Prevent unsafe removal or demotion of the last active Super Admin
  IF (TG_OP = 'UPDATE') THEN
    IF (OLD.role = 'super_admin' AND (NEW.role <> 'super_admin' OR NEW.account_status NOT IN ('active', 'approved'))) THEN
      SELECT COUNT(*) INTO v_super_admin_count
      FROM public.profiles
      WHERE role = 'super_admin'
        AND account_status IN ('active', 'approved')
        AND id <> OLD.id;

      IF v_super_admin_count = 0 THEN
        RAISE EXCEPTION 'Cannot demote or deactivate the last remaining active Super Admin.';
      END IF;
    END IF;
  END IF;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trigger_enforce_admin_limits ON public.profiles;
CREATE TRIGGER trigger_enforce_admin_limits
  BEFORE INSERT OR UPDATE OF role, account_status ON public.profiles
  FOR EACH ROW EXECUTE PROCEDURE public.check_admin_account_limit();

CREATE OR REPLACE FUNCTION public.prevent_last_super_admin_delete()
RETURNS TRIGGER AS $$
DECLARE
  v_super_admin_count INTEGER;
BEGIN
  IF OLD.role = 'super_admin' THEN
    SELECT COUNT(*) INTO v_super_admin_count
    FROM public.profiles
    WHERE role = 'super_admin'
      AND account_status IN ('active', 'approved')
      AND id <> OLD.id;

    IF v_super_admin_count = 0 THEN
      RAISE EXCEPTION 'Cannot delete the last remaining active Super Admin.';
    END IF;
  END IF;
  RETURN OLD;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trigger_prevent_super_admin_delete ON public.profiles;
CREATE TRIGGER trigger_prevent_super_admin_delete
  BEFORE DELETE ON public.profiles
  FOR EACH ROW EXECUTE PROCEDURE public.prevent_last_super_admin_delete();

-- --------------------------------------------------------------------
-- 5. SECURE FIRST SUPER ADMIN BOOTSTRAP FUNCTION
-- --------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.bootstrap_first_super_admin(target_email TEXT)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_existing_super_admins INTEGER;
  v_target_profile public.profiles%ROWTYPE;
BEGIN
  -- Check if any super admin already exists
  SELECT COUNT(*) INTO v_existing_super_admins
  FROM public.profiles
  WHERE role = 'super_admin' AND account_status IN ('active', 'approved');

  IF v_existing_super_admins > 0 THEN
    RETURN jsonb_build_object(
      'success', false,
      'message', 'A Super Admin is already configured and active. First-time initialization is permanently locked.'
    );
  END IF;

  -- Find profile
  SELECT * INTO v_target_profile
  FROM public.profiles
  WHERE LOWER(email) = LOWER(TRIM(target_email));

  IF NOT FOUND THEN
    -- If user exists in auth.users but not yet in profiles, create profile
    INSERT INTO public.profiles (id, full_name, email, role, account_status, username)
    SELECT id, COALESCE(raw_user_meta_data->>'full_name', split_part(email, '@', 1)), email, 'super_admin', 'active', split_part(email, '@', 1)
    FROM auth.users
    WHERE LOWER(email) = LOWER(TRIM(target_email))
    RETURNING * INTO v_target_profile;

    IF NOT FOUND THEN
      RETURN jsonb_build_object(
        'success', false,
        'message', 'No registered account found with email: ' || target_email || '. Please register first.'
      );
    END IF;
  ELSE
    UPDATE public.profiles
    SET role = 'super_admin',
        account_status = 'active',
        updated_at = timezone('utc'::text, now())
    WHERE id = v_target_profile.id;
  END IF;

  RETURN jsonb_build_object(
    'success', true,
    'message', 'Successfully initialized ' || target_email || ' as Super Admin.',
    'userId', v_target_profile.id
  );
END;
$$;

-- --------------------------------------------------------------------
-- 6. AUTH REGISTRATION HOOK TRIGGER (ALWAYS PENDING & USER ROLE)
-- --------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.handle_new_auth_user()
RETURNS TRIGGER AS $$
BEGIN
  -- CRITICAL SECURITY RULE: Public registration can NEVER create privileged roles.
  -- Force role = 'user' and account_status = 'pending'
  INSERT INTO public.profiles (id, username, full_name, email, role, account_status, department, employee_id)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'username', split_part(NEW.email, '@', 1)),
    COALESCE(NEW.raw_user_meta_data->>'full_name', split_part(NEW.email, '@', 1)),
    NEW.email,
    'user',
    'pending',
    COALESCE(NEW.raw_user_meta_data->>'department', 'KBZLife Operations'),
    COALESCE(NEW.raw_user_meta_data->>'employee_id', 'KBZ-EMP-' || substr(md5(random()::text), 1, 4))
  )
  ON CONFLICT (id) DO UPDATE SET
    email = EXCLUDED.email,
    updated_at = timezone('utc'::text, now());
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE PROCEDURE public.handle_new_auth_user();

-- --------------------------------------------------------------------
-- 7. CORE LMS TABLES (Courses, Channels, Enrollments, Progress, Audit)
-- --------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.courses (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    title TEXT NOT NULL,
    description TEXT NOT NULL,
    thumbnail_url TEXT NOT NULL,
    category TEXT NOT NULL DEFAULT 'Core Curriculum',
    published BOOLEAN NOT NULL DEFAULT true,
    duration_hours NUMERIC(4,1) DEFAULT 4.5,
    modules_count INTEGER DEFAULT 6,
    learning_outcomes TEXT[] DEFAULT ARRAY[]::TEXT[],
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now()),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

CREATE TABLE IF NOT EXISTS public.channels (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    course_id UUID REFERENCES public.courses(id) ON DELETE SET NULL,
    title TEXT NOT NULL,
    description TEXT NOT NULL,
    thumbnail_url TEXT NOT NULL,
    published BOOLEAN NOT NULL DEFAULT true,
    order_index INTEGER NOT NULL DEFAULT 1,
    tags TEXT[] DEFAULT ARRAY[]::TEXT[],
    key_highlights TEXT[] DEFAULT ARRAY[]::TEXT[],
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now()),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

CREATE TABLE IF NOT EXISTS public.course_enrollments (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    course_id UUID NOT NULL REFERENCES public.courses(id) ON DELETE CASCADE,
    status TEXT NOT NULL CHECK (status IN ('enrolled', 'completed', 'revoked')) DEFAULT 'enrolled',
    assigned_by UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
    assigned_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now()),
    expires_at TIMESTAMPTZ,
    restriction_note TEXT,
    CONSTRAINT unique_user_course_enrollment UNIQUE(user_id, course_id)
);

CREATE TABLE IF NOT EXISTS public.channel_access (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    channel_id UUID NOT NULL REFERENCES public.channels(id) ON DELETE CASCADE,
    status TEXT NOT NULL CHECK (status IN ('granted', 'revoked')) DEFAULT 'granted',
    assigned_by UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
    assigned_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now()),
    expires_at TIMESTAMPTZ,
    restriction_note TEXT,
    CONSTRAINT unique_user_channel_access UNIQUE(user_id, channel_id)
);

CREATE TABLE IF NOT EXISTS public.learning_progress (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    course_id UUID REFERENCES public.courses(id) ON DELETE CASCADE,
    channel_id UUID REFERENCES public.channels(id) ON DELETE CASCADE,
    lesson_id TEXT,
    progress_percentage INTEGER NOT NULL DEFAULT 0 CHECK (progress_percentage >= 0 AND progress_percentage <= 100),
    completion_status TEXT NOT NULL CHECK (completion_status IN ('not_started', 'in_progress', 'completed')) DEFAULT 'not_started',
    last_accessed_at TIMESTAMPTZ DEFAULT timezone('utc'::text, now()),
    completed_at TIMESTAMPTZ,
    time_spent_seconds INTEGER DEFAULT 0,
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now()),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

CREATE TABLE IF NOT EXISTS public.admin_audit_logs (
    id TEXT PRIMARY KEY DEFAULT ('log_' || substr(md5(random()::text), 1, 8)),
    admin_user_id UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
    admin_name TEXT NOT NULL,
    target_user_id UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
    target_user_name TEXT,
    action TEXT NOT NULL,
    entity_type TEXT NOT NULL,
    entity_id TEXT,
    details TEXT NOT NULL,
    ip_address TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

-- --------------------------------------------------------------------
-- 8. NEWS, VIDEOS, TOP PERFORMERS, TEAM & MOTTO
-- --------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.company_news (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    title TEXT NOT NULL,
    summary TEXT NOT NULL,
    content TEXT[] NOT NULL DEFAULT ARRAY[]::TEXT[],
    cover_image_url TEXT NOT NULL,
    category TEXT NOT NULL DEFAULT 'Corporate Milestone',
    status TEXT NOT NULL CHECK (status IN ('draft', 'published')) DEFAULT 'published',
    is_featured BOOLEAN NOT NULL DEFAULT false,
    author_id UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
    author_name TEXT DEFAULT 'Internal Communications Desk',
    read_time_minutes INTEGER DEFAULT 3,
    published_at TIMESTAMPTZ DEFAULT timezone('utc'::text, now()),
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now()),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

CREATE TABLE IF NOT EXISTS public.company_videos (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    title TEXT NOT NULL,
    description TEXT NOT NULL,
    video_url TEXT NOT NULL,
    thumbnail_url TEXT,
    category TEXT NOT NULL DEFAULT 'Leadership Address',
    display_order INTEGER NOT NULL DEFAULT 1,
    duration TEXT DEFAULT '12:45',
    status TEXT NOT NULL CHECK (status IN ('draft', 'published')) DEFAULT 'published',
    author_id UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
    published_at TIMESTAMPTZ DEFAULT timezone('utc'::text, now()),
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now()),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

CREATE TABLE IF NOT EXISTS public.top_performers (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    full_name TEXT NOT NULL,
    role_title TEXT NOT NULL,
    branch_name TEXT NOT NULL,
    month_year TEXT NOT NULL,
    sales_volume TEXT NOT NULL,
    policies_count INTEGER NOT NULL,
    avatar_url TEXT,
    achievement_highlight TEXT NOT NULL,
    display_order INTEGER NOT NULL DEFAULT 1,
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now()),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

CREATE TABLE IF NOT EXISTS public.hod_motto (
    id TEXT PRIMARY KEY DEFAULT 'hod_motto_singleton',
    hod_name TEXT NOT NULL,
    hod_title TEXT NOT NULL,
    motto_quote TEXT NOT NULL,
    motto_body TEXT NOT NULL,
    avatar_url TEXT,
    signature_url TEXT,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

CREATE TABLE IF NOT EXISTS public.ld_team_members (
    id TEXT PRIMARY KEY DEFAULT ('tm_' || substr(md5(random()::text), 1, 8)),
    full_name TEXT NOT NULL,
    role_title TEXT NOT NULL,
    avatar_url TEXT,
    specialization TEXT NOT NULL,
    bio TEXT NOT NULL,
    email TEXT,
    display_order INTEGER NOT NULL DEFAULT 1,
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now()),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

-- --------------------------------------------------------------------
-- 9. LICENSE TRAINING (Chapters, Lessons, Quizzes, Attempts)
-- --------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.license_chapters (
    id TEXT PRIMARY KEY DEFAULT ('lic_ch_' || substr(md5(random()::text), 1, 8)),
    title TEXT NOT NULL,
    chapter_number INTEGER NOT NULL DEFAULT 1,
    description TEXT,
    summary TEXT,
    estimated_minutes INTEGER NOT NULL DEFAULT 60,
    passing_score INTEGER NOT NULL DEFAULT 80,
    display_order INTEGER NOT NULL DEFAULT 1,
    is_published BOOLEAN NOT NULL DEFAULT true,
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now()),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

CREATE TABLE IF NOT EXISTS public.license_training_lessons (
    id TEXT PRIMARY KEY DEFAULT ('lic_lesson_' || substr(md5(random()::text), 1, 8)),
    chapter_id TEXT REFERENCES public.license_chapters(id) ON DELETE CASCADE,
    title TEXT NOT NULL,
    description TEXT,
    content_type TEXT NOT NULL CHECK (content_type IN ('video', 'pdf', 'link')) DEFAULT 'video',
    lesson_type TEXT DEFAULT 'video',
    file_url TEXT,
    content_url TEXT,
    thumbnail_url TEXT,
    duration TEXT DEFAULT '15:00',
    display_order INTEGER NOT NULL DEFAULT 1,
    is_published BOOLEAN NOT NULL DEFAULT true,
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now()),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

CREATE TABLE IF NOT EXISTS public.license_quizzes (
    id TEXT PRIMARY KEY DEFAULT ('lic_quiz_' || substr(md5(random()::text), 1, 8)),
    chapter_id TEXT REFERENCES public.license_chapters(id) ON DELETE CASCADE,
    title TEXT NOT NULL,
    description TEXT,
    passing_score INTEGER NOT NULL DEFAULT 80,
    time_limit_minutes INTEGER NOT NULL DEFAULT 20,
    is_published BOOLEAN NOT NULL DEFAULT true,
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now()),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

CREATE TABLE IF NOT EXISTS public.license_quiz_questions (
    id TEXT PRIMARY KEY DEFAULT ('lqq_' || substr(md5(random()::text), 1, 8)),
    quiz_id TEXT NOT NULL REFERENCES public.license_quizzes(id) ON DELETE CASCADE,
    question_text TEXT NOT NULL,
    options JSONB NOT NULL DEFAULT '[]'::jsonb,
    correct_option_index INTEGER NOT NULL DEFAULT 0,
    explanation TEXT,
    display_order INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS public.license_quiz_attempts (
    id TEXT PRIMARY KEY DEFAULT ('lqa_' || substr(md5(random()::text), 1, 8)),
    quiz_id TEXT NOT NULL,
    chapter_id TEXT,
    user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    user_name TEXT,
    user_email TEXT,
    score INTEGER NOT NULL DEFAULT 0,
    total_questions INTEGER NOT NULL DEFAULT 0,
    percentage INTEGER NOT NULL DEFAULT 0,
    passed BOOLEAN NOT NULL DEFAULT false,
    answers JSONB DEFAULT '{}'::jsonb,
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

-- --------------------------------------------------------------------
-- 10. SKILL DEVELOPMENT (Categories, Resources, Quizzes, Attempts)
-- --------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.skill_categories (
    id TEXT PRIMARY KEY DEFAULT ('sk_cat_' || substr(md5(random()::text), 1, 8)),
    title TEXT NOT NULL,
    description TEXT NOT NULL,
    icon_name TEXT DEFAULT 'Award',
    display_order INTEGER NOT NULL DEFAULT 1,
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now()),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

CREATE TABLE IF NOT EXISTS public.skill_development_resources (
    id TEXT PRIMARY KEY DEFAULT ('sk_res_' || substr(md5(random()::text), 1, 8)),
    category_id TEXT REFERENCES public.skill_categories(id) ON DELETE CASCADE,
    title TEXT NOT NULL,
    description TEXT NOT NULL,
    content_type TEXT NOT NULL CHECK (content_type IN ('video', 'pdf', 'link')) DEFAULT 'video',
    resource_type TEXT DEFAULT 'video',
    content_url TEXT NOT NULL,
    file_url TEXT,
    thumbnail_url TEXT NOT NULL,
    duration TEXT DEFAULT '20:00',
    display_order INTEGER NOT NULL DEFAULT 1,
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now()),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

CREATE TABLE IF NOT EXISTS public.skill_quizzes (
    id TEXT PRIMARY KEY DEFAULT ('sk_quiz_' || substr(md5(random()::text), 1, 8)),
    category_id TEXT REFERENCES public.skill_categories(id) ON DELETE CASCADE,
    resource_id TEXT REFERENCES public.skill_development_resources(id) ON DELETE CASCADE,
    title TEXT NOT NULL,
    description TEXT,
    passing_score INTEGER NOT NULL DEFAULT 80,
    is_published BOOLEAN NOT NULL DEFAULT true,
    questions JSONB NOT NULL DEFAULT '[]'::jsonb,
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now()),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

CREATE TABLE IF NOT EXISTS public.skill_quiz_attempts (
    id TEXT PRIMARY KEY DEFAULT ('sqa_' || substr(md5(random()::text), 1, 8)),
    quiz_id TEXT NOT NULL,
    category_id TEXT,
    resource_id TEXT,
    user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    user_name TEXT,
    user_email TEXT,
    score INTEGER NOT NULL DEFAULT 0,
    total_questions INTEGER NOT NULL DEFAULT 0,
    percentage INTEGER NOT NULL DEFAULT 0,
    passed BOOLEAN NOT NULL DEFAULT false,
    answers JSONB DEFAULT '{}'::jsonb,
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

-- --------------------------------------------------------------------
-- 11. PRODUCT KNOWLEDGE HUB (Items, Quizzes, Attempts)
-- --------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.product_knowledge_items (
    id TEXT PRIMARY KEY DEFAULT ('prod_' || substr(md5(random()::text), 1, 8)),
    title TEXT NOT NULL,
    tagline TEXT,
    category TEXT NOT NULL DEFAULT 'Individual Life',
    description TEXT NOT NULL,
    brochure_url TEXT,
    proposal_form_url TEXT,
    policy_wording_url TEXT,
    thumbnail_url TEXT NOT NULL,
    key_features TEXT[] DEFAULT ARRAY[]::TEXT[],
    benefits TEXT[] DEFAULT ARRAY[]::TEXT[],
    eligibility_criteria TEXT,
    faqs JSONB DEFAULT '[]'::jsonb,
    display_order INTEGER NOT NULL DEFAULT 1,
    is_published BOOLEAN NOT NULL DEFAULT true,
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now()),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

CREATE TABLE IF NOT EXISTS public.product_quizzes (
    id TEXT PRIMARY KEY DEFAULT ('pq_' || substr(md5(random()::text), 1, 8)),
    product_id TEXT NOT NULL REFERENCES public.product_knowledge_items(id) ON DELETE CASCADE,
    title TEXT NOT NULL,
    description TEXT,
    passing_score INTEGER NOT NULL DEFAULT 80,
    is_published BOOLEAN NOT NULL DEFAULT true,
    questions JSONB NOT NULL DEFAULT '[]'::jsonb,
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now()),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

CREATE TABLE IF NOT EXISTS public.product_quiz_attempts (
    id TEXT PRIMARY KEY DEFAULT ('pqa_' || substr(md5(random()::text), 1, 8)),
    quiz_id TEXT NOT NULL,
    product_id TEXT,
    user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    user_name TEXT,
    user_email TEXT,
    score INTEGER NOT NULL DEFAULT 0,
    total_questions INTEGER NOT NULL DEFAULT 0,
    percentage INTEGER NOT NULL DEFAULT 0,
    passed BOOLEAN NOT NULL DEFAULT false,
    answers JSONB DEFAULT '{}'::jsonb,
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

-- --------------------------------------------------------------------
-- 12. COMPANY BULLETINS
-- --------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.company_bulletins (
    id TEXT PRIMARY KEY DEFAULT ('bulletin_' || substr(md5(random()::text), 1, 8)),
    title TEXT NOT NULL,
    description TEXT NOT NULL,
    category TEXT NOT NULL DEFAULT 'Announcement',
    pdf_url TEXT NOT NULL,
    file_name TEXT,
    file_size BIGINT DEFAULT 0,
    formatted_file_size TEXT,
    published BOOLEAN NOT NULL DEFAULT true,
    status TEXT NOT NULL CHECK (status IN ('draft', 'published')) DEFAULT 'published',
    published_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now()),
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now()),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now()),
    author_id UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
    author_name TEXT DEFAULT 'KBZLife Administration',
    department TEXT DEFAULT 'Corporate Communications',
    tags TEXT[] DEFAULT ARRAY[]::TEXT[],
    reference_no TEXT,
    priority TEXT NOT NULL DEFAULT 'normal',
    verified BOOLEAN NOT NULL DEFAULT true,
    color_theme TEXT NOT NULL DEFAULT 'blue_orange'
);

-- --------------------------------------------------------------------
-- 13. STORAGE BUCKETS (Public & Private)
-- --------------------------------------------------------------------
INSERT INTO storage.buckets (id, name, public)
VALUES
  ('profile-pictures', 'profile-pictures', true),
  ('company-news', 'company-news', true),
  ('video-thumbnails', 'video-thumbnails', true),
  ('top-performers', 'top-performers', true),
  ('product-images', 'product-images', true),
  ('company-bulletins', 'company-bulletins', false),
  ('training-materials', 'training-materials', false)
ON CONFLICT (id) DO UPDATE SET
  public = EXCLUDED.public;

-- --------------------------------------------------------------------
-- 14. ROW LEVEL SECURITY (RLS) POLICIES
-- --------------------------------------------------------------------

-- Enable RLS across all tables
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.courses ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.channels ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.course_enrollments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.channel_access ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.learning_progress ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.admin_audit_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.company_news ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.company_videos ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.top_performers ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.hod_motto ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.ld_team_members ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.license_chapters ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.license_training_lessons ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.license_quizzes ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.license_quiz_questions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.license_quiz_attempts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.skill_categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.skill_development_resources ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.skill_quizzes ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.skill_quiz_attempts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.product_knowledge_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.product_quizzes ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.product_quiz_attempts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.company_bulletins ENABLE ROW LEVEL SECURITY;

-- PROFILES POLICIES
DROP POLICY IF EXISTS "Users can read own profile" ON public.profiles;
CREATE POLICY "Users can read own profile" ON public.profiles
  FOR SELECT USING (auth.uid() = id OR public.is_admin(auth.uid()));

DROP POLICY IF EXISTS "Users can update own personal details" ON public.profiles;
CREATE POLICY "Users can update own personal details" ON public.profiles
  FOR UPDATE USING (auth.uid() = id)
  WITH CHECK (
    auth.uid() = id 
    AND role = (SELECT role FROM public.profiles WHERE id = auth.uid())
    AND account_status = (SELECT account_status FROM public.profiles WHERE id = auth.uid())
  );

DROP POLICY IF EXISTS "Super Admins manage all profiles" ON public.profiles;
CREATE POLICY "Super Admins manage all profiles" ON public.profiles
  FOR ALL USING (public.is_super_admin(auth.uid()));

DROP POLICY IF EXISTS "Admins can update user account statuses" ON public.profiles;
CREATE POLICY "Admins can update user account statuses" ON public.profiles
  FOR UPDATE USING (public.is_admin(auth.uid()));

-- GENERAL READ POLICIES FOR ACTIVE USERS
DROP POLICY IF EXISTS "Active users view published courses" ON public.courses;
CREATE POLICY "Active users view published courses" ON public.courses
  FOR SELECT USING (published = true AND public.is_account_active(auth.uid()));

DROP POLICY IF EXISTS "Active users view published channels" ON public.channels;
CREATE POLICY "Active users view published channels" ON public.channels
  FOR SELECT USING (published = true AND public.is_account_active(auth.uid()));

DROP POLICY IF EXISTS "Active users view published news" ON public.company_news;
CREATE POLICY "Active users view published news" ON public.company_news
  FOR SELECT USING (status = 'published' AND public.is_account_active(auth.uid()));

DROP POLICY IF EXISTS "Active users view published videos" ON public.company_videos;
CREATE POLICY "Active users view published videos" ON public.company_videos
  FOR SELECT USING (status = 'published' AND public.is_account_active(auth.uid()));

DROP POLICY IF EXISTS "Active users view top performers" ON public.top_performers;
CREATE POLICY "Active users view top performers" ON public.top_performers
  FOR SELECT USING (public.is_account_active(auth.uid()));

DROP POLICY IF EXISTS "Active users view hod motto" ON public.hod_motto;
CREATE POLICY "Active users view hod motto" ON public.hod_motto
  FOR SELECT USING (public.is_account_active(auth.uid()));

DROP POLICY IF EXISTS "Active users view team members" ON public.ld_team_members;
CREATE POLICY "Active users view team members" ON public.ld_team_members
  FOR SELECT USING (public.is_account_active(auth.uid()));

DROP POLICY IF EXISTS "Active users view published license chapters" ON public.license_chapters;
CREATE POLICY "Active users view published license chapters" ON public.license_chapters
  FOR SELECT USING (is_published = true AND public.is_account_active(auth.uid()));

DROP POLICY IF EXISTS "Active users view published license lessons" ON public.license_training_lessons;
CREATE POLICY "Active users view published license lessons" ON public.license_training_lessons
  FOR SELECT USING (is_published = true AND public.is_account_active(auth.uid()));

DROP POLICY IF EXISTS "Active users view published license quizzes" ON public.license_quizzes;
CREATE POLICY "Active users view published license quizzes" ON public.license_quizzes
  FOR SELECT USING (is_published = true AND public.is_account_active(auth.uid()));

DROP POLICY IF EXISTS "Active users view published license questions" ON public.license_quiz_questions;
CREATE POLICY "Active users view published license questions" ON public.license_quiz_questions
  FOR SELECT USING (public.is_account_active(auth.uid()));

DROP POLICY IF EXISTS "Active users view published skill categories" ON public.skill_categories;
CREATE POLICY "Active users view published skill categories" ON public.skill_categories
  FOR SELECT USING (public.is_account_active(auth.uid()));

DROP POLICY IF EXISTS "Active users view published skill resources" ON public.skill_development_resources;
CREATE POLICY "Active users view published skill resources" ON public.skill_development_resources
  FOR SELECT USING (public.is_account_active(auth.uid()));

DROP POLICY IF EXISTS "Active users view published skill quizzes" ON public.skill_quizzes;
CREATE POLICY "Active users view published skill quizzes" ON public.skill_quizzes
  FOR SELECT USING (is_published = true AND public.is_account_active(auth.uid()));

DROP POLICY IF EXISTS "Active users view published products" ON public.product_knowledge_items;
CREATE POLICY "Active users view published products" ON public.product_knowledge_items
  FOR SELECT USING (is_published = true AND public.is_account_active(auth.uid()));

DROP POLICY IF EXISTS "Active users view published product quizzes" ON public.product_quizzes;
CREATE POLICY "Active users view published product quizzes" ON public.product_quizzes
  FOR SELECT USING (is_published = true AND public.is_account_active(auth.uid()));

DROP POLICY IF EXISTS "Active users view published bulletins" ON public.company_bulletins;
CREATE POLICY "Active users view published bulletins" ON public.company_bulletins
  FOR SELECT USING (published = true AND public.is_account_active(auth.uid()));

-- USER PERSONAL PROGRESS & QUIZ ATTEMPTS POLICIES
DROP POLICY IF EXISTS "Users can read own progress" ON public.learning_progress;
CREATE POLICY "Users can read own progress" ON public.learning_progress
  FOR SELECT USING (user_id = auth.uid() OR public.is_admin(auth.uid()));

DROP POLICY IF EXISTS "Users can upsert own progress" ON public.learning_progress;
CREATE POLICY "Users can upsert own progress" ON public.learning_progress
  FOR ALL USING (user_id = auth.uid() OR public.is_admin(auth.uid()));

DROP POLICY IF EXISTS "Users can read own license attempts" ON public.license_quiz_attempts;
CREATE POLICY "Users can read own license attempts" ON public.license_quiz_attempts
  FOR SELECT USING (user_id = auth.uid() OR public.is_admin(auth.uid()));

DROP POLICY IF EXISTS "Users can insert own license attempts" ON public.license_quiz_attempts;
CREATE POLICY "Users can insert own license attempts" ON public.license_quiz_attempts
  FOR INSERT WITH CHECK (user_id = auth.uid() OR public.is_admin(auth.uid()));

DROP POLICY IF EXISTS "Users can read own skill attempts" ON public.skill_quiz_attempts;
CREATE POLICY "Users can read own skill attempts" ON public.skill_quiz_attempts
  FOR SELECT USING (user_id = auth.uid() OR public.is_admin(auth.uid()));

DROP POLICY IF EXISTS "Users can insert own skill attempts" ON public.skill_quiz_attempts;
CREATE POLICY "Users can insert own skill attempts" ON public.skill_quiz_attempts
  FOR INSERT WITH CHECK (user_id = auth.uid() OR public.is_admin(auth.uid()));

DROP POLICY IF EXISTS "Users can read own product attempts" ON public.product_quiz_attempts;
CREATE POLICY "Users can read own product attempts" ON public.product_quiz_attempts
  FOR SELECT USING (user_id = auth.uid() OR public.is_admin(auth.uid()));

DROP POLICY IF EXISTS "Users can insert own product attempts" ON public.product_quiz_attempts;
CREATE POLICY "Users can insert own product attempts" ON public.product_quiz_attempts
  FOR INSERT WITH CHECK (user_id = auth.uid() OR public.is_admin(auth.uid()));

-- ADMIN FULL ACCESS POLICIES
DROP POLICY IF EXISTS "Admins manage courses" ON public.courses;
CREATE POLICY "Admins manage courses" ON public.courses FOR ALL USING (public.is_admin(auth.uid()));

DROP POLICY IF EXISTS "Admins manage channels" ON public.channels;
CREATE POLICY "Admins manage channels" ON public.channels FOR ALL USING (public.is_admin(auth.uid()));

DROP POLICY IF EXISTS "Admins manage enrollments" ON public.course_enrollments;
CREATE POLICY "Admins manage enrollments" ON public.course_enrollments FOR ALL USING (public.is_admin(auth.uid()));

DROP POLICY IF EXISTS "Admins manage channel access" ON public.channel_access;
CREATE POLICY "Admins manage channel access" ON public.channel_access FOR ALL USING (public.is_admin(auth.uid()));

DROP POLICY IF EXISTS "Admins manage news" ON public.company_news;
CREATE POLICY "Admins manage news" ON public.company_news FOR ALL USING (public.is_admin(auth.uid()));

DROP POLICY IF EXISTS "Admins manage videos" ON public.company_videos;
CREATE POLICY "Admins manage videos" ON public.company_videos FOR ALL USING (public.is_admin(auth.uid()));

DROP POLICY IF EXISTS "Admins manage top performers" ON public.top_performers;
CREATE POLICY "Admins manage top performers" ON public.top_performers FOR ALL USING (public.is_admin(auth.uid()));

DROP POLICY IF EXISTS "Admins manage hod motto" ON public.hod_motto;
CREATE POLICY "Admins manage hod motto" ON public.hod_motto FOR ALL USING (public.is_admin(auth.uid()));

DROP POLICY IF EXISTS "Admins manage team members" ON public.ld_team_members;
CREATE POLICY "Admins manage team members" ON public.ld_team_members FOR ALL USING (public.is_admin(auth.uid()));

DROP POLICY IF EXISTS "Admins manage license chapters" ON public.license_chapters;
CREATE POLICY "Admins manage license chapters" ON public.license_chapters FOR ALL USING (public.is_admin(auth.uid()));

DROP POLICY IF EXISTS "Admins manage license lessons" ON public.license_training_lessons;
CREATE POLICY "Admins manage license lessons" ON public.license_training_lessons FOR ALL USING (public.is_admin(auth.uid()));

DROP POLICY IF EXISTS "Admins manage license quizzes" ON public.license_quizzes;
CREATE POLICY "Admins manage license quizzes" ON public.license_quizzes FOR ALL USING (public.is_admin(auth.uid()));

DROP POLICY IF EXISTS "Admins manage license questions" ON public.license_quiz_questions;
CREATE POLICY "Admins manage license questions" ON public.license_quiz_questions FOR ALL USING (public.is_admin(auth.uid()));

DROP POLICY IF EXISTS "Admins manage skill categories" ON public.skill_categories;
CREATE POLICY "Admins manage skill categories" ON public.skill_categories FOR ALL USING (public.is_admin(auth.uid()));

DROP POLICY IF EXISTS "Admins manage skill resources" ON public.skill_development_resources;
CREATE POLICY "Admins manage skill resources" ON public.skill_development_resources FOR ALL USING (public.is_admin(auth.uid()));

DROP POLICY IF EXISTS "Admins manage skill quizzes" ON public.skill_quizzes;
CREATE POLICY "Admins manage skill quizzes" ON public.skill_quizzes FOR ALL USING (public.is_admin(auth.uid()));

DROP POLICY IF EXISTS "Admins manage products" ON public.product_knowledge_items;
CREATE POLICY "Admins manage products" ON public.product_knowledge_items FOR ALL USING (public.is_admin(auth.uid()));

DROP POLICY IF EXISTS "Admins manage product quizzes" ON public.product_quizzes;
CREATE POLICY "Admins manage product quizzes" ON public.product_quizzes FOR ALL USING (public.is_admin(auth.uid()));

DROP POLICY IF EXISTS "Admins manage company bulletins" ON public.company_bulletins;
CREATE POLICY "Admins manage company bulletins" ON public.company_bulletins FOR ALL USING (public.is_admin(auth.uid()));

DROP POLICY IF EXISTS "Admins manage audit logs" ON public.admin_audit_logs;
CREATE POLICY "Admins manage audit logs" ON public.admin_audit_logs FOR ALL USING (public.is_admin(auth.uid()));

-- STORAGE RLS POLICIES
DROP POLICY IF EXISTS "Public read for public media buckets" ON storage.objects;
CREATE POLICY "Public read for public media buckets" ON storage.objects
  FOR SELECT USING (bucket_id IN ('profile-pictures', 'company-news', 'video-thumbnails', 'top-performers', 'product-images'));

DROP POLICY IF EXISTS "Authorized users read private training materials and bulletins" ON storage.objects;
CREATE POLICY "Authorized users read private training materials and bulletins" ON storage.objects
  FOR SELECT USING (
    bucket_id IN ('company-bulletins', 'training-materials')
    AND public.is_account_active(auth.uid())
  );

DROP POLICY IF EXISTS "Admins manage all storage objects" ON storage.objects;
CREATE POLICY "Admins manage all storage objects" ON storage.objects
  FOR ALL USING (public.is_admin(auth.uid()));

DROP POLICY IF EXISTS "Authenticated users upload profile pictures" ON storage.objects;
CREATE POLICY "Authenticated users upload profile pictures" ON storage.objects
  FOR INSERT WITH CHECK (bucket_id = 'profile-pictures' AND auth.uid()::text = (storage.foldername(name))[1]);

-- --------------------------------------------------------------------
-- 15. SEED DATA & INITIAL SUPER ADMIN INITIALIZATION
-- --------------------------------------------------------------------
INSERT INTO public.hod_motto (id, hod_name, hod_title, motto_quote, motto_body, avatar_url)
VALUES (
  'hod_motto_singleton',
  'Daw Khin San Tint',
  'Head of Learning & Development, KBZLife Insurance',
  'Empowering Frontline Excellence Through Structured Knowledge and Ethical Governance',
  'At KBZLife, our advisory force is the heartbeat of financial protection for families across Myanmar. Continuous learning is not merely a professional milestone—it is our fiduciary commitment to market trust, regulatory integrity, and consumer prosperity.',
  'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=400&q=80'
)
ON CONFLICT (id) DO UPDATE SET
  motto_quote = EXCLUDED.motto_quote,
  motto_body = EXCLUDED.motto_body;

INSERT INTO public.license_chapters (id, chapter_number, title, description, summary, estimated_minutes, passing_score, display_order, is_published)
VALUES
  ('lic_ch_001', 1, 'IBRB Statutory Framework & Agent Licensing Regulations', 'Core regulatory requirements, ethics, and statutory compliance established by the Insurance Business Regulatory Board of Myanmar.', 'Master the essential regulatory framework governing Myanmar life insurance agency operations.', 60, 80, 1, true),
  ('lic_ch_002', 2, 'Life Insurance Principles, Underwriting & Risk Assessment', 'Core principles of utmost good faith, insurable interest, medical/financial underwriting, and policy issuance.', 'Comprehensive foundations of risk evaluation, insurable interest, and underwriting decision workflows.', 75, 80, 2, true),
  ('lic_ch_003', 3, 'Market Conduct, Policyholder Rights & Claims Governance', 'Fair market conduct rules, transparent policy disclosure, cooling-off provisions, and dispute escalation protocols.', 'Essential standards for maintaining customer protection, transparency, and ethical advisory practices.', 90, 80, 3, true)
ON CONFLICT (id) DO NOTHING;

INSERT INTO public.license_training_lessons (id, chapter_id, title, description, content_type, file_url, thumbnail_url, duration, display_order, is_published)
VALUES
  ('lic_lesson_001', 'lic_ch_001', 'Module 1: IBRB Statutory Code & Agent Licensing Conduct', 'Comprehensive walkthrough of Myanmar Insurance Business Regulatory Board compliance mandates.', 'video', '/uploads/IBRB_Licensing_Agent_Code.mp4', 'https://images.unsplash.com/photo-1450133064473-71024230f91b?auto=format&fit=crop&w=1200&q=80', '24:18', 1, true),
  ('lic_lesson_002', 'lic_ch_001', 'Module 2: Anti-Money Laundering & Terrorist Financing (AML/CFT) Compliance', 'Core screening obligations, suspicious transaction identification, and mandatory reporting protocols.', 'pdf', '/uploads/KBZLife_AML_CFT_Compliance_2026.pdf', 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&w=1200&q=80', '32 Pages', 2, true),
  ('lic_lesson_003', 'lic_ch_002', 'Module 3: Fair Market Conduct & Policyholder Rights Manual', 'Detailed guidance on transparent disclosure, cooling-off rights, and claim dispute management.', 'pdf', '/uploads/Fair_Market_Conduct_Manual.pdf', 'https://images.unsplash.com/photo-1554224155-8d04cb21cd6c?auto=format&fit=crop&w=1200&q=80', '28 Pages', 3, true)
ON CONFLICT (id) DO NOTHING;

INSERT INTO public.company_bulletins (id, title, description, category, pdf_url, file_name, file_size, formatted_file_size, published, status, priority, department, reference_no)
VALUES
  ('bulletin_001', 'Official Market Conduct and Policyholder Protection Directive 2026', 'Compulsory regulatory standards and compliance benchmarks issued by the Executive Committee for all nationwide frontline advisors and bancassurance partners.', 'Governance & Policy', '/uploads/Fair_Market_Conduct_Manual.pdf', 'Fair_Market_Conduct_Manual.pdf', 2516582, '2.4 MB', true, 'published', 'urgent', 'Compliance & Legal', 'KBZ-2026-DIR01'),
  ('bulletin_002', 'Annual Anti-Money Laundering & CFT Risk Assessment Manual', 'Updated institutional handbook on customer due diligence, PEP verification, and suspicious transaction escalation for retail branch operations.', 'Regulatory Notice', '/uploads/KBZLife_AML_CFT_Compliance_2026.pdf', 'KBZLife_AML_CFT_Compliance_2026.pdf', 3250585, '3.1 MB', true, 'published', 'high', 'AML / Risk Operations', 'KBZ-2026-AML04')
ON CONFLICT (id) DO NOTHING;

-- Final output
SELECT 'KBZLife LMS Complete Master Schema successfully created. Run bootstrap_first_super_admin(''your-email@kbzlife.com'') to provision your Super Admin.' AS status;
